# SMF-Forgot-Password-Email-Only
Only allow email addresses to be used when sending forgot password reminder emails (instead of emails and usernames)
