[hr]
[center][color=blue][size=14pt][b]Forgot Password Email Only v1.0[/b][/size][/color]
[url=http://www.simplemachines.org/community/index.php?action=profile;u=328403][b]By Colin[/b][/url]
[/center]
[hr]
[b][size=10pt][u]Introduction[/u][/size][/b]
This mod allows the user to hide any topic from the board index and message index views.  It also allows the user to show the topic again, both from the topic display and the message index views.

[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
Copyright (c) 2016, Colin Schoen
All rights reserved.

Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/
